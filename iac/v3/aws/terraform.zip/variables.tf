# variables.tf

# k8s + helm variables
# =====================================================================
variable "kubeconfig_path" {
  description = "Config file of k8s"
  type        = string
  default     = "/home/ubuntu/.kube/config"
}

variable "k8s_service_namespace" {
  description = "Name of Service Namespace of k8s"
  type        = string
  default     = "service"
}

variable "helm_name" {
  description = "Helm release name"
  type        = string
  default     = "nginx-ingress"
}

variable "helm_repository" {
  description = "Helm chart repo URL"
  type        = string
  sensitive = true
  default     = "https://kubernetes.github.io/ingress-nginx"
}

variable "helm_chart" {
  description = "Helm chart name"
  type        = string
  default     = "ingress-nginx"
}

variable "helm_namespace" {
  description = "Kubernetes namespace for the release"
  type        = string
  default     = "ingress-nginx"
}

variable "helm_create_namespace" {
  description = "Whether to create the namespace"
  type        = bool
  default     = true
}

variable "helm_service_type" {
  description = "Kubernetes Service type (LoadBalancer, ClusterIP 등)"
  type        = string
  default     = "LoadBalancer"
}

variable "helm_lb_type" {
  description = "AWS LoadBalancer 타입 (nlb 또는 alb)"
  type        = string
  default     = "nlb"
}

variable "helm_publish_service_enabled" {
  description = "controller.publishService.enabled 설정"
  type        = bool
  default     = true
}

# =====================================================================================================


# default variables
# =====================================================================
variable "project_name" {
  description = "Project name"
  type        = string
  default     = "leafresh"
}

variable "region" {
  description = "AWS region"
  type        = string
  default     = "ap-northeast-2"
}

variable "gcp_region" {
  description = "GCP region"
  type        = string
  default     = "asia-northeast3"
}

variable "gcp_project_id" {
  description = "Project Name of GCP that includes Cloud DNS"
  type        = string
  default     = "leafresh"
}



# tag variables
# =====================================================================
variable "tag_environment" {
  description = "Runnung Environment as tag"
  type        = string
  default     = "Dev"
}



# VPC variables
# =====================================================================
variable "vpc_cidr_block" {
  description = "The CIDR block for the VPC (e.g., 10.0.0.0/18)."
  type        = string
  sensitive = true
}



# subnet variables
# =====================================================================
variable "public_subnet_cidrs" {
  description = "Map of AZ suffixes to public subnet CIDRs"
  type        = map(string)
  default = {
  a = "10.0.1.0/24"
  c = "10.0.101.0/24"
  }
}

variable "private_subnet_cidrs" {
  description = "Map of AZ-suffix-index to private subnet CIDRs (e.g. a-1)"
  type        = map(string)
  default = {
  "a-1" = "10.0.2.0/24"
  "a-2" = "10.0.3.0/24"
  "c-1" = "10.0.102.0/24"
  "c-2" = "10.0.103.0/24"
  }
}



# S3 variables
# =====================================================================
variable "s3_bucket_suffixes" {
  description = "List of suffixes for S3 buckets"
  type        = list(string)
  default     = ["images", "prod-images", "logs"]
}



# RDS variables
# =====================================================================
variable "rds_username" {
  description = "Master username for the RDS instance"
  type        = string
  default     = "root"
}

variable "rds_password" {
  description = "Master password for the RDS instance"
  type        = string
  sensitive   = true
}

variable "rds_instance_class" {
  description = "Instance class for the RDS instance"
  type        = string
  default     = "db.m5.xlarge"
}

variable "rds_engine" {
  description = "Instance engine for the RDS instance"
  type        = string
  default     = "mysql"
}

variable "rds_engine_version" {
  description = "Instance engine version for the RDS instance"
  type        = string
  default     = "8.0"
}

variable "rds_storage_type" {
  description = "Storage type for the RDS instance"
  type        = string
  default     = "gp3"
}

variable "rds_multi_az" {
  description = "Multi AZ setting for the RDS instance"
  type        = bool
  default     = false
}



# SQS variables
# =====================================================================
variable "sqs_fifo_queue_names" {
  description = "List of FIFO SQS queue suffixes"
  type        = list(string)
  default     = ["order", "image", "feedback", "feedback-result", "auth-result"]
}

variable "sqs_fifo_dlq_queue_names" {
  description = "List of FIFO SQS queues that require DLQ"
  type        = list(string)
  default     = ["order", "image", "feedback-result"]
}

variable "sqs_fifo_max_receive_count" {
  description = "MaxReceiveCount for DLQ redrive policy"
  type        = number
  default     = 5
}



# EC2 variables & locals
# =====================================================================
variable "ec2_access_key_id" {
  description = "EC2 credentials ID"
  type        = string
  sensitive   = true
}

variable "ec2_secret_access_key" {
  description = "EC2 credentials key"
  type        = string
  sensitive   = true
}


locals {
  ec2_master_node = [
    {
      name          = "master"
      ami           = "ami-03e38f46f79020a70" # "ami-08943a151bd468f4e"
      instance_type = "t3.medium"
      subnet_id     = module.subnets.private_subnet_ids_map["a-1"]
      role          = "k8s"
    },
  ]

  ec2_worker_nodes = [
    {
      name          = "fe"
      ami           = "ami-03e38f46f79020a70" # "ami-08943a151bd468f4e"
      instance_type = "t3.medium"
      subnet_id     = module.subnets.private_subnet_ids_map["a-1"]
      role          = "k8s"
    },
    {
      name          = "be"
      ami           = "ami-03e38f46f79020a70" # "ami-08943a151bd468f4e"
      instance_type = "t3.medium"
      subnet_id     = module.subnets.private_subnet_ids_map["a-1"]
      role          = "k8s"
    },
    {
      name          = "argocd"
      ami           = "ami-03e38f46f79020a70" # "ami-08943a151bd468f4e"
      instance_type = "t3.medium"
      subnet_id     = module.subnets.private_subnet_ids_map["a-1"]
      role          = "k8s"
    },
    {
      name          = "ai-cpu"
      ami           = "ami-03e38f46f79020a70" # "ami-08943a151bd468f4e"
      instance_type = "t3.xlarge"
      subnet_id     = module.subnets.private_subnet_ids_map["a-1"]
      role          = "gpu"
    },
    {
      name          = "ai-gpu"
      ami           = "ami-060449aa9aa36d665"
      instance_type = "t3.xlarge" # "g4dn.xlarge"
      subnet_id     = module.subnets.private_subnet_ids_map["a-1"]
      role          = "gpu"
    },
    {
      name          = "redis-master"
      ami           = "ami-03e38f46f79020a70" # "ami-08943a151bd468f4e"
      instance_type = "t3.medium"
      subnet_id     = module.subnets.private_subnet_ids_map["a-2"]
      role          = "k8s"
    },
    {
      name          = "redis-slave"
      ami           = "ami-03e38f46f79020a70" # "ami-08943a151bd468f4e"
      instance_type = "t3.medium"
      subnet_id     = module.subnets.private_subnet_ids_map["c-2"]
      role          = "k8s"
    },
    {
      name          = "monitoring"
      ami           = "ami-03e38f46f79020a70" # "ami-08943a151bd468f4e"
      instance_type = "t3.medium"
      subnet_id     = module.subnets.private_subnet_ids_map["c-1"]
      role          = "k8s"
    },
  ]

  asg_k8s = {
    subnet_ids = [
      module.subnets.private_subnet_ids_map["a-1"],
      module.subnets.private_subnet_ids_map["c-1"],
    ]
    min_size         = 1
    max_size         = 2
    desired_capacity = 1
  }
}



# ECR variables
# =====================================================================
variable "ecr_repository_names" {
  description = "Lists of ECR repository to create."
  type        = list(string)
  default     = ["ecr"]
}



# DNS variables
# =====================================================================
variable "gcp_dns_zone_name" {
  description = "Managed Zone of GCP DNS"
  type        = string
  sensitive = true
  default     = "dev-leafresh-app"
}

variable "gcp_dns_domain_name" {
  description = "Domain name of GCP DNS"
  type        = string
  sensitive = true
  default     = "dev-leafresh.app"
}


# ACM variables
# =====================================================================
variable "vpn_server_domain" {
  description = "Server Domain of VPN"
  type        = string
  sensitive = true
}

variable "vpn_client_domain" {
  description = "Client Domain of VPN"
  type        = string
  sensitive = true
}


# VPN variables
# =====================================================================
locals {
  subnet_map = {
    "a-1" = module.subnets.private_subnet_ids_map["a-1"]
    "c-1" = module.subnets.private_subnet_ids_map["c-1"]
  }
}


variable "vpn_client_cidr_block" {
  description = "CIDR block assigned to VPN"
  type        = string
  sensitive = true
}