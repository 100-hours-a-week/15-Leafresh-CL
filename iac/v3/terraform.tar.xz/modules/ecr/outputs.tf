output "repository_urls" {
  description = "ECR 리포지터리 URL 맵 (key는 repository_names의 value)"
  value = {
    for key, repo in aws_ecr_repository.repos :
    key => repo.repository_url
  }
}